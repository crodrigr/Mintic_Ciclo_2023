
package co.edu.unab.appdocentesfinal.datos;

import co.edu.unab.appdocentesfinal.dominio.Docente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class DocenteDao {
    
    private static final String SQL_SELECT="SELECT id, nombres, apellidos, documento, categoria, horas, honorarios FROM db_docente.docentes";
    
    private static final String SQL_SELECT_BY="SELECT id, nombres, apellidos, documento, categoria, horas, honorarios FROM db_docente.docentes WHERE id=?";
    
    private static final String SQL_INSERT="INSERT INTO  db_docente.docentes (nombres,apellidos,documento,categoria,horas) VALUES(?,?,?,?,?)";
    
    private static final String SQL_UPDATE="UPDATE db_docente.docentes SET nombres=?,apellidos=?,documento=?,categoria=?,horas=?,honorarios=? WHERE id=?";
    
    private static final String SQL_DELETE="DELETE FROM db_docente.docentes WHERE id=?";
        
    public List<Docente> listar(){
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        Docente docente=null;
        List<Docente> docentes=new ArrayList<>();
        
        try{
          conn=Conexion.getConnection();
          stmt=conn.prepareStatement(SQL_SELECT);
          rs=stmt.executeQuery();
          while(rs.next()){
             int idDocente=rs.getInt("id");
             String nombres=rs.getString("nombres");
             String apellidos=rs.getString("apellidos");
             String documento=rs.getString("documento");
             int categoria=rs.getInt("categoria");
             int horas=rs.getInt("horas");
             double honorarios=rs.getDouble("honorarios");
             docente=new Docente(idDocente,nombres,apellidos,documento,categoria,horas,honorarios);
             docentes.add(docente);         
          
          }
        }catch(SQLException ex){
           System.out.println(ex.getMessage());
        }finally{
          Conexion.close(rs);
          Conexion.close(stmt);
          Conexion.close(conn);        
        }
        return docentes;
    
    }    
    public Docente encontrar(Docente docente){
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;       
        try{
          conn=Conexion.getConnection();
          stmt=conn.prepareStatement(SQL_SELECT_BY);
          stmt.setInt(1, docente.getId());
          rs=stmt.executeQuery();
          while(rs.next()){
             String nombres=rs.getString("nombres");
             String apellidos=rs.getString("apellidos");
             String documento=rs.getString("documento");
             int categoria=rs.getInt("categoria");
             int horas=rs.getInt("horas");
             double honorarios=rs.getDouble("honorarios");             
             docente.setNombres(nombres);
             docente.setApellidos(apellidos);
             docente.setDocumento(documento);
             docente.setCategoria(categoria);
             docente.setHoras(horas);
             docente.setHonorios(honorarios);
          }
        }catch(SQLException ex){
           System.out.println(ex.getMessage());
        }finally{
          Conexion.close(rs);
          Conexion.close(stmt);
          Conexion.close(conn);        
        }
        return docente;
    
    }
    public int insertar(Docente docente){
        Connection conn=null;
        PreparedStatement stmt=null;       
        int row=0;        
        try{
          conn=Conexion.getConnection();
          stmt=conn.prepareStatement(SQL_INSERT);
          stmt.setString(1, docente.getNombres());
          stmt.setString(2, docente.getApellidos());
          stmt.setString(3, docente.getDocumento());
          stmt.setInt(4, docente.getCategoria());
          stmt.setInt(5, docente.getHoras());         
          row=stmt.executeUpdate();          
        }catch(SQLException ex){
           System.out.println(ex.getMessage());
        }finally{          
          Conexion.close(stmt);
          Conexion.close(conn);        
        }
        return row;    
    }
    public int actulizar(Docente docente){
        Connection conn=null;
        PreparedStatement stmt=null;
        int row=0;        
        try{
          conn=Conexion.getConnection();
          stmt=conn.prepareStatement(SQL_UPDATE);
          stmt.setString(1, docente.getNombres());
          stmt.setString(2, docente.getApellidos());
          stmt.setString(3, docente.getDocumento());
          stmt.setInt(4, docente.getCategoria());
          stmt.setInt(5, docente.getHoras());
          stmt.setDouble(6, docente.getHonorios());
          stmt.setInt(7, docente.getId());
          row=stmt.executeUpdate();          
        }catch(SQLException ex){
           System.out.println(ex.getMessage());
        }finally{
          Conexion.close(stmt);
          Conexion.close(conn);        
        }
        return row;
    
    }    
    public int eliminar(Docente docente){
        Connection conn=null;
        PreparedStatement stmt=null;
        int row=0;        
        try{
          conn=Conexion.getConnection();
          stmt=conn.prepareStatement(SQL_DELETE);
          stmt.setInt(1, docente.getId());
          row=stmt.executeUpdate();          
        }catch(SQLException ex){
           System.out.println(ex.getMessage());
        }finally{
          Conexion.close(stmt);
          Conexion.close(conn);        
        }
        return row;
    
    }
}
