
package co.edu.unab.appdocentesfinal.dominio;

public class Docente {
    
    private int id;
    private String nombres;
    private String apellidos;
    private String documento;
    private int    categoria;
    private int    horas;
    private double honorios;
    
    public Docente(){
    
    }

    public Docente(String nombres, String apellidos, String documento, int categoria, int horas) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.documento = documento;
        this.categoria = categoria;
        this.horas = horas;        
    }

    public Docente(int id, String nombres, String apellidos, String documento, int categoria, int horas, double honorios) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.documento = documento;
        this.categoria = categoria;
        this.horas = horas;
        this.honorios = honorios;
    }
   
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public double getHonorios() {
        return honorios;
    }

    public void setHonorios(double honorios) {
        this.honorios = honorios;
    }
    
    public void calcularHonorarios(){
       this.honorios=this.horas*Categoria.getValorPorCategoria(this.categoria); 
    }
    
         
    
    
}
