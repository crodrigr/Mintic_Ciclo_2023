
package vistas;

import co.edu.unab.appdocentesfinal.datos.DocenteDao;
import co.edu.unab.appdocentesfinal.dominio.Docente;
import java.util.List;

public class AppDocente {
    
    public static void main(String arg[]){
        List<Docente> docentes=loadData();
        MainView principal=new MainView();
        principal.setDocentes(docentes);
        principal.mostrar();
        principal.setVisible(true);
    }
    
    public static List<Docente> loadData(){
        DocenteDao docenteDao=new DocenteDao();
        return docenteDao.listar();  
    }
    
}
